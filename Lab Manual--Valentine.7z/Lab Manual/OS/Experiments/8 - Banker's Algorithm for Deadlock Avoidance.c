#include <stdio.h>
#include <stdlib.h>

int max[100][100], alloc[100][100], need[100][100], avail[100], n, r;

void input() {
    printf("Enter the number of processes and resources: ");
    scanf("%d%d", &n, &r);

    printf("\nEnter Maximum Resource Matrix:\n");
    for (int i = 0; i < n; i++) {
        printf("Process %d: ", i);
        for (int j = 0; j < r; j++) {
            scanf("%d", &max[i][j]);
        }
    }

    printf("\nEnter Allocation Matrix:\n");
    for (int i = 0; i < n; i++) {
        printf("Process %d: ", i);
        for (int j = 0; j < r; j++) {
            scanf("%d", &alloc[i][j]);
            need[i][j] = max[i][j] - alloc[i][j];
        }
    }

    printf("\nEnter Available Resources: ");
    for (int j = 0; j < r; j++)
        scanf("%d", &avail[j]);

    printf("\nNeed Matrix (Max - Allocation):\n");
    for (int i = 0; i < n; i++) {
        printf("Process %d: ", i);
        for (int j = 0; j < r; j++) {
            printf("%d ", need[i][j]);
        }
        printf("\n");
    }
}

void checkSafeState() {
    int f[100] = {0}, s[100], w[100], c = 0;
    for (int i = 0; i < r; i++) w[i] = avail[i];

    while (c < n) {
        int found = 0;
        for (int i = 0; i < n; i++) {
            if (!f[i]) {
                int canExecute = 1;
                for (int j = 0; j < r; j++) {
                    if (need[i][j] > w[j]) {
                        canExecute = 0;
                        break;
                    }
                }
                if (canExecute) {
                    for (int j = 0; j < r; j++)
                        w[j] += alloc[i][j];
                    s[c++] = i;
                    f[i] = found = 1;
                }
            }
        }
        if (!found) {
            printf("\nSystem is in a deadlock state!\n");
            return;
        }
    }

    printf("\nSystem is in a safe state.\nSafe Sequence: ");
    for (int i = 0; i < n; i++)
        printf("P%d ", s[i]);
    printf("\n");
}

int main() {
    printf("Banker's Algorithm\n");
    input();
    checkSafeState();
    return 0;
}