#include <stdio.h>

int main() {
    int f, p;
    int pages[50], frame[10], hit = 0, count[50] = {0}, time[50] = {0};
    int i, j, flag, least, minTime, temp;

    printf("Enter no of frames : ");
    scanf("%d", &f);

    printf("Enter no of pages : ");
    scanf("%d", &p);

    for (i = 0; i < f; i++)
        frame[i] = -1;

    printf("Enter page no :\n");
    for (i = 0; i < p; i++)
        scanf("%d", &pages[i]);

    for (i = 0; i < p; i++) {
        count[pages[i]]++;
        time[pages[i]] = i;
        flag = 1;
        least = frame[0];

        for (j = 0; j < f; j++) {
            if (frame[j] == -1 || frame[j] == pages[i]) {
                if (frame[j] != -1)
                    hit++;
                flag = 0;
                frame[j] = pages[i];
                break;
            }
            if (count[least] > count[frame[j]]) {
                least = frame[j];
            }
        }

        if (flag) {
            minTime = 50;
            for (j = 0; j < f; j++) {
                if (count[frame[j]] == count[least] && time[frame[j]] < minTime) {
                    temp = j;
                    minTime = time[frame[j]];
                }
            }
            count[frame[temp]] = 0;
            frame[temp] = pages[i];
        }

        for (j = 0; j < f; j++)
            printf("%d\n", frame[j]);  // print each frame in a new line as per your sample
    }

    printf("Page hit = %d\n", hit);

    return 0;
}
