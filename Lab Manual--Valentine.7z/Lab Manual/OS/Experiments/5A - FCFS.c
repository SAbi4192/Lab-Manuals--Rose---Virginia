#include <stdio.h>

struct fcfs {
    int pid, btime, wtime, ttime;
} p[10];

int main() {
    int i, n, totwtime = 0, totttime = 0;
    printf("\nFCFS Scheduling...\nEnter the number of processes: ");
    scanf("%d", &n);

    for (i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("\nEnter Burst Time for P%d: ", p[i].pid);
        scanf("%d", &p[i].btime);

        p[i].wtime = (i == 0) ? 0 : p[i - 1].wtime + p[i - 1].btime;
        p[i].ttime = p[i].wtime + p[i].btime;
        totwtime += p[i].wtime;
        totttime += p[i].ttime;
    }

    printf("\nP\tBT\tWT\tTT\n");
    for (i = 0; i < n; i++)
        printf("%d\t%d\t%d\t%d\n", p[i].pid, p[i].btime, p[i].wtime, p[i].ttime);

    printf("\nTotal WT: %d\nAvg WT: %.2f\nTotal TT: %d\nAvg TT: %.2f\n",
           totwtime, (float)totwtime / n, totttime, (float)totttime / n);
    return 0;
}
