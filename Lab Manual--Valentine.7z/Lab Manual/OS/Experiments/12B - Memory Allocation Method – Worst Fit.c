#include <stdio.h>

#define MAX 25

void main() {
    int frag[MAX], b[MAX], f[MAX], i, j, nb, nf, temp, highest;
    static int bf[MAX], ff[MAX];

    printf("\n\t Memory Management Scheme - Worst Fit\n");

    // Input block and file counts
    printf("Enter the number of blocks: ");
    scanf("%d", &nb);

    printf("Enter the number of files: ");
    scanf("%d", &nf);

    // Input block sizes
    printf("\nEnter the size of the blocks:\n");
    for (i = 1; i <= nb; i++) {
        printf("Block %d: ", i);
        scanf("%d", &b[i]);
    }

    // Input file sizes
    printf("Enter the size of the files:\n");
    for (i = 1; i <= nf; i++) {
        printf("File %d: ", i);
        scanf("%d", &f[i]);
    }

    // Worst Fit Allocation
    for (i = 1; i <= nf; i++) {
        highest = -1;
        for (j = 1; j <= nb; j++) {
            if (bf[j] != 1) { // block not allocated
                temp = b[j] - f[i];
                if (temp >= 0 && temp > highest) {
                    ff[i] = j;
                    highest = temp;
                }
            }
        }
        frag[i] = highest;
        bf[ff[i]] = 1; // Mark block as allocated
    }

    // Output results
    printf("\nFile No.\tFile Size\tBlock No.\tBlock Size\tFragment\n");
    for (i = 1; i <= nf; i++)
        printf("%d\t\t%d\t\t%d\t\t%d\t\t%d\n",
               i, f[i], ff[i], b[ff[i]], frag[i]);
}
