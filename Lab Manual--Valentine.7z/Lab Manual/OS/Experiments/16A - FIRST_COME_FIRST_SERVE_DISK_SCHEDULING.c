#include <stdio.h>
#include <stdlib.h>

void fcfs(int arr[], int head, int size) {
    int total_movement = 0;
    printf("Sequence of disk accesses:\n");
    for (int i = 0; i < size; i++) {
        int distance = abs(head - arr[i]);
        total_movement += distance;
        printf("%d ", arr[i]);
        head = arr[i];
    }
    printf("\nTotal head movement: %d\n", total_movement);
}

int main() {
    int n, head;
    printf("Enter the number of requests: ");
    scanf("%d", &n);
    
    int arr[n];
    printf("Enter the requests:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("Enter the initial position of the head: ");
    scanf("%d", &head);

    fcfs(arr, head, n);
    return 0;
}
