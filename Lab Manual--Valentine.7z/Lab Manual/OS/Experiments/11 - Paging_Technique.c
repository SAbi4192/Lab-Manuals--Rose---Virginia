#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

pthread_t tid[2];
int counter = 0;
pthread_mutex_t lock;

void* doSomeThing(void *arg) {
    pthread_mutex_lock(&lock);

    counter++;
    printf("\nJob %d started\n", counter);
    
    usleep(100000); // Simulate work

    printf("\nJob %d finished\n", counter);

    pthread_mutex_unlock(&lock);
    return NULL;
}

int main(void) {
    if (pthread_mutex_init(&lock, NULL) != 0) {
        printf("\nMutex init failed\n");
        return 1;
    }

    for (int i = 0; i < 2; i++) {
        int err = pthread_create(&(tid[i]), NULL, &doSomeThing, NULL);
        if (err != 0) {
            printf("\nCan't create thread: %s\n", strerror(err));
        } else {
            printf("\nThread created successfully\n");
        }
    }

    // Ensure all threads finish execution before destroying mutex
    for (int i = 0; i < 2; i++) {
        pthread_join(tid[i], NULL);
    }

    pthread_mutex_destroy(&lock);
    printf("\nAll jobs completed.\n");

    return 0;
}
