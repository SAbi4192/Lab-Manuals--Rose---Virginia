#include <stdio.h>

struct sjf {
    int pid, btime, wtime, ttime;
} p[10];

void sortProcesses(struct sjf p[], int n) {
    for (int i = 0; i < n - 1; i++)
        for (int j = i + 1; j < n; j++)
            if (p[i].btime > p[j].btime) {
                struct sjf temp = p[i];
                p[i] = p[j];
                p[j] = temp;
            }
}

int main() {
    int n, totwtime = 0, totttime = 0;

    printf("\nSJF Scheduling...\nEnter the number of processes: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter Burst Time for P%d: ", p[i].pid);
        scanf("%d", &p[i].btime);
    }

    sortProcesses(p, n);

    for (int i = 0; i < n; i++) {
        p[i].wtime = (i == 0) ? 0 : p[i - 1].wtime + p[i - 1].btime;
        p[i].ttime = p[i].wtime + p[i].btime;
        totwtime += p[i].wtime;
        totttime += p[i].ttime;
    }

    printf("\nP\tBT\tWT\tTT\n");
    for (int i = 0; i < n; i++)
        printf("%d\t%d\t%d\t%d\n", p[i].pid, p[i].btime, p[i].wtime, p[i].ttime);

    printf("\nTotal WT: %d\nAvg WT: %.2f\nTotal TT: %d\nAvg TT: %.2f\n",
           totwtime, (float)totwtime / n, totttime, (float)totttime / n);

    return 0;
}
