#include <stdio.h>
#include <limits.h> // For INT_MAX

#define MAX 25

int main() {
    int frag[MAX], b[MAX], f[MAX], bf[MAX] = {0}, ff[MAX];
    int nb, nf, temp, lowest;

    printf("\nEnter the number of blocks: ");
    scanf("%d", &nb);
    printf("Enter the number of files: ");
    scanf("%d", &nf);

    printf("\nEnter the size of the blocks:\n");
    for (int i = 0; i < nb; i++) {
        printf("Block %d: ", i + 1);
        scanf("%d", &b[i]);
    }

    printf("\nEnter the size of the files:\n");
    for (int i = 0; i < nf; i++) {
        printf("File %d: ", i + 1);
        scanf("%d", &f[i]);
    }

    for (int i = 0; i < nf; i++) {
        lowest = INT_MAX; // Correct initialization
        ff[i] = -1; // Default to not allocated

        for (int j = 0; j < nb; j++) {
            if (!bf[j] && b[j] >= f[i] && b[j] - f[i] < lowest) {
                ff[i] = j;
                lowest = b[j] - f[i];
            }
        }

        if (ff[i] != -1) {
            frag[i] = lowest;
            bf[ff[i]] = 1; // Mark block as allocated
        } else {
            frag[i] = -1; // No allocation possible
        }
    }

    printf("\nFile No\tFile Size\tBlock No\tBlock Size\tFragment");
    for (int i = 0; i < nf; i++) {
        if (ff[i] != -1) {
            printf("\n%d\t%d\t\t%d\t\t%d\t\t%d", i + 1, f[i], ff[i] + 1, b[ff[i]], frag[i]);
        } else {
            printf("\n%d\t%d\t\tNot Allocated", i + 1, f[i]);
        }
    }

    return 0;
}
