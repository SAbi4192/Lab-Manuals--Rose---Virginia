#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

pthread_t tid[2];

void* doSomeThing(void *arg) {
    pthread_t id = pthread_self();

    if (pthread_equal(id, tid[0])) {
        printf("\n First thread processing\n");
    } else {
        printf("\n Second thread processing\n");
    }

    usleep(100000); // Simulate work without busy waiting
    return NULL;
}

int main(void) {
    int err;

    for (int i = 0; i < 2; i++) {
        err = pthread_create(&(tid[i]), NULL, &doSomeThing, NULL);
        if (err != 0) {
            printf("\nCan't create thread: %s\n", strerror(err));
        } else {
            printf("\nThread created successfully\n");
        }
    }

    // Ensure threads complete execution before exiting
    for (int i = 0; i < 2; i++) {
        pthread_join(tid[i], NULL);
    }

    printf("\nAll threads finished execution.\n");
    return 0;
}
