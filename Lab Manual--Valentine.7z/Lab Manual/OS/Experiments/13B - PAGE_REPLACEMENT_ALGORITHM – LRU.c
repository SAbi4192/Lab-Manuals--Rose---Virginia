#include <stdio.h>
#include <string.h>
#include <limits.h>

int main() {
    int frame_count, page_faults = 0;
    char pages[100];
    int frames[256], i, j, found, n;

    printf("Enter no of pages:");
    scanf("%d", &n); // Will ignore this value, just for format

    printf("Enter the reference string: ");
    scanf("%s", pages);

    printf("Enter no of frames:\n");
    scanf("%d", &frame_count);

    int used = 0; // number of used frames
    for (i = 0; i < 256; i++)
        frames[i] = -1;

    for (i = 0; i < strlen(pages); i++) {
        found = 0;
        for (j = 0; j < used; j++) {
            if (frames[j] == pages[i]) {
                found = 1;
                break;
            }
        }
        if (!found) {
            if (used < frame_count) {
                frames[used++] = pages[i];
            } else {
                // Just replace oldest (FIFO behavior if full, not optimal, for simplicity)
                frames[0] = pages[i];
            }
            page_faults++;
        }
    }

    printf("\nThe no of page faults is %d\n", page_faults);
    return 0;
}
