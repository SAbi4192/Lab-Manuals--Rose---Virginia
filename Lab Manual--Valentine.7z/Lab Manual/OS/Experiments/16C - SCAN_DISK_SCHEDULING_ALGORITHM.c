#include <stdio.h>
#include <stdlib.h>

void sort(int arr[], int n) {
    int i, j;
    for (i = 0; i < n - 1; i++)
        for (j = i + 1; j < n; j++)
            if (arr[i] > arr[j]) {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
}

void scan(int request_queue[], int head, int n, int max) {
    int total_movement = 0;
    int i;

    // Add the head and max if direction is right (simulate the end of the disk)
    request_queue[n++] = head;
    request_queue[n++] = max;

    sort(request_queue, n);

    // Find the index of head in the sorted list
    for (i = 0; i < n; i++)
        if (request_queue[i] == head)
            break;

    printf("Sequence of disk accesses:\n");

    // Move right from head to end
    for (int j = i; j < n; j++) {
        printf("%d ", request_queue[j]);
        total_movement += abs(head - request_queue[j]);
        head = request_queue[j];
    }

    // Then move to the left from the element before head
    for (int j = i - 1; j >= 0; j--) {
        printf("%d ", request_queue[j]);
        total_movement += abs(head - request_queue[j]);
        head = request_queue[j];
    }

    printf("\nTotal head movement: %d\n", total_movement);
}

int main() {
    int n, head, max, request_queue[100];

    printf("Enter the number of requests: ");
    scanf("%d", &n);

    printf("Enter the requests:\n");
    for (int i = 0; i < n; i++)
        scanf("%d", &request_queue[i]);

    printf("Enter the initial position of the head: ");
    scanf("%d", &head);

    printf("Enter the maximum track number: ");
    scanf("%d", &max);

    scan(request_queue, head, n, max);
    return 0;
}
