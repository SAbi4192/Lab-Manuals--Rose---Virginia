#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>

void createFile(char *f) {
    FILE *fp = fopen(f, "w");
    if (fp) {
        printf("File '%s' created.\n", f);
        fclose(fp);
    } else printf("Error creating file.\n");
}

void listFiles() {
    struct dirent *d;
    DIR *dir = opendir(".");
    if (!dir) { printf("Error opening directory.\n"); return; }
    printf("\nFiles:\n");
    while ((d = readdir(dir)))
        if (d->d_type == DT_REG) printf("%s\n", d->d_name);
    closedir(dir);
}

void readFile(char *f) {
    FILE *fp = fopen(f, "r");
    if (!fp) { printf("Cannot open '%s'.\n", f); return; }
    printf("\nContents of '%s':\n", f);
    char ch; while ((ch = fgetc(fp)) != EOF) putchar(ch);
    fclose(fp);
}

void deleteFile(char *f) {
    if (!remove(f)) printf("Deleted '%s'.\n", f);
    else printf("Cannot delete '%s'.\n", f);
}

int main() {
    int ch; char f[50];
    while (1) {
        printf("\n1.Create 2.List 3.Read 4.Delete 5.Exit\nChoice: ");
        if (scanf("%d", &ch) != 1) { while (getchar() != '\n'); continue; }
        if (ch == 5) break;
        if (ch >= 1 && ch <= 4) {
            if (ch != 2) {
                printf("Filename: "); scanf("%s", f);
            }
            if (ch == 1) createFile(f);
            else if (ch == 2) listFiles();
            else if (ch == 3) readFile(f);
            else if (ch == 4) deleteFile(f);
        } else printf("Invalid choice.\n");
    }
    return 0;
}
