#include <stdio.h>
#include <stdlib.h>

int findShortestSeekTime(int request_queue[], int head, int n) {
    int distance, min_distance = 9999, index = -1;
    for (int i = 0; i < n; i++) {
        distance = abs(head - request_queue[i]);
        if (distance < min_distance) {
            min_distance = distance;
            index = i;
        }
    }
    return index;
}

void sstf(int request_queue[], int head, int n) {
    int total_movement = 0, index;

    printf("Sequence of disk accesses:\n");
    while (n > 0) {
        index = findShortestSeekTime(request_queue, head, n);
        total_movement += abs(head - request_queue[index]);
        head = request_queue[index];
        printf("%d ", head);

        for (int i = index; i < n - 1; i++) {
            request_queue[i] = request_queue[i + 1];
        }
        n--;
    }

    printf("\nTotal head movement: %d\n", total_movement);
}

int main() {
    int n, head, request_queue[100];

    printf("Enter the number of requests: ");
    scanf("%d", &n);

    printf("Enter the requests:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &request_queue[i]);
    }

    printf("Enter the initial position of the head: ");
    scanf("%d", &head);

    sstf(request_queue, head, n);

    return 0;
}
