#include <stdio.h>

#define MAX 25

int main() {
    int frag[MAX], b[MAX], f[MAX], bf[MAX] = {0}, ff[MAX];
    int nb, nf, temp;

    printf("\n\tMemory Management Scheme - First Fit");
    printf("\nEnter the number of blocks: ");
    scanf("%d", &nb);
    printf("Enter the number of files: ");
    scanf("%d", &nf);

    printf("\nEnter the size of the blocks:\n");
    for (int i = 0; i < nb; i++) {
        printf("Block %d: ", i + 1);
        scanf("%d", &b[i]);
    }

    printf("\nEnter the size of the files:\n");
    for (int i = 0; i < nf; i++) {
        printf("File %d: ", i + 1);
        scanf("%d", &f[i]);
    }

    for (int i = 0; i < nf; i++) {
        ff[i] = -1; // Initialize file allocation as -1 (not allocated)
        for (int j = 0; j < nb; j++) {
            if (!bf[j] && b[j] >= f[i]) { // Check if block is free and large enough
                ff[i] = j;
                frag[i] = b[j] - f[i]; // Calculate fragmentation
                bf[j] = 1; // Mark block as allocated
                break;
            }
        }
    }

    printf("\nFile_no\tFile_size\tBlock_no\tBlock_size\tFragment");
    for (int i = 0; i < nf; i++) {
        if (ff[i] != -1) {
            printf("\n%d\t%d\t\t%d\t\t%d\t\t%d", i + 1, f[i], ff[i] + 1, b[ff[i]], frag[i]);
        } else {
            printf("\n%d\t%d\t\tNot Allocated", i + 1, f[i]);
        }
    }

    return 0;
}
