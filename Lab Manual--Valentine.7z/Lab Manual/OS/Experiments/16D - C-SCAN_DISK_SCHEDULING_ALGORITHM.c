#include <stdio.h>
#include <stdlib.h>

void quickSort(int arr[], int low, int high) {
    if (low < high) {
        int pivot = arr[high], i = low - 1, j;
        for (j = low; j < high; j++) {
            if (arr[j] < pivot) {
                i++;
                int temp = arr[i]; arr[i] = arr[j]; arr[j] = temp;
            }
        }
        int temp = arr[i + 1]; arr[i + 1] = arr[high]; arr[high] = temp;
        quickSort(arr, low, i);
        quickSort(arr, i + 2, high);
    }
}

void cscan(int request_queue[], int head, int n, int max) {
    quickSort(request_queue, 0, n - 1); 
    int total_movement = 0, direction = 1, i;
    printf("Sequence of disk accesses:\n");

    // Service requests to the right of the head
    for (i = 0; i < n; i++) {
        if (request_queue[i] >= head) {
            total_movement += abs(head - request_queue[i]);
            head = request_queue[i];
            printf("%d ", request_queue[i]);
        }
    }

    // Move to max and jump to 0
    if (head != max) {
        total_movement += abs(head - max);
        head = 0;
        printf("%d ", max);
        total_movement += max;
    }

    // Service remaining requests from the beginning
    for (i = 0; i < n; i++) {
        if (request_queue[i] < head) {
            total_movement += abs(head - request_queue[i]);
            head = request_queue[i];
            printf("%d ", request_queue[i]);
        }
    }

    printf("\nTotal head movement: %d\n", total_movement);
}

int main() {
    int n, head, max, request_queue[100];

    printf("Enter the number of requests: "); scanf("%d", &n);
    printf("Enter the requests:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &request_queue[i]);
        if (request_queue[i] < 0 || request_queue[i] > max) {
            printf("Invalid request! Must be between 0 and max track.\n");
            i--;
        }
    }

    printf("Enter the initial position of the head: "); scanf("%d", &head);
    printf("Enter the maximum track number: "); scanf("%d", &max);

    cscan(request_queue, head, n, max);
    return 0;
}
