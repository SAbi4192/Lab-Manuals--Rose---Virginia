#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include <string.h>

#define MEM_SIZE 1024
#define SHM_KEY 2345

int main() {
    int shmid;
    void *shared_memory;
    char buff[100];

    // Create shared memory segment
    shmid = shmget((key_t)SHM_KEY, MEM_SIZE, 0666 | IPC_CREAT);
    if (shmid == -1) {
        printf("Failed to create shared memory segment.\n");
        return 1;
    }
    printf("Key of shared memory: %d\n", shmid);

    // Attach shared memory
    shared_memory = shmat(shmid, NULL, 0);
    if (shared_memory == (void *)-1) {
        printf("Failed to attach shared memory.\n");
        return 1;
    }
    printf("Process attached at %p\n", shared_memory);

    // Get input from user
    printf("Enter data to write to shared memory: ");
    fgets(buff, sizeof(buff), stdin);
    
    strcpy((char *)shared_memory, buff);
    printf("You wrote: %s\n", (char *)shared_memory);

    // Reading from shared memory
    printf("Reading data from shared memory...\n");
    printf("DATA: %s\n", (char *)shared_memory);
    printf("DONE\n");

    // Remove shared memory segment
    printf("Removing shared memory segment...\n");
    if (shmctl(shmid, IPC_RMID, NULL) == -1) {
        printf("Can't remove shared memory segment.\n");
    } else {
        printf("Removed successfully.\n");
    }

    return 0;
}
