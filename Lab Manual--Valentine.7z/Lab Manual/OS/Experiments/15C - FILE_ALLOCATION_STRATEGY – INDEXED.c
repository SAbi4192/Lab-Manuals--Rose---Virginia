#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Employee {
    int id;
    char name[50];
    float salary;
};

void add(FILE *f) {
    struct Employee e;
    printf("Enter employee ID: ");
    scanf("%d", &e.id);
    printf("Enter employee name: ");
    scanf("%s", e.name);
    printf("Enter employee salary: ");
    scanf("%f", &e.salary);
    fseek(f, (e.id - 1) * sizeof(e), SEEK_SET);
    fwrite(&e, sizeof(e), 1, f);
    printf("Employee added successfully.\n");
}

void search(FILE *f) {
    int id;
    struct Employee e;
    printf("Enter employee ID to search: ");
    scanf("%d", &id);
    fseek(f, (id - 1) * sizeof(e), SEEK_SET);
    fread(&e, sizeof(e), 1, f);
    if (e.id == id)
        printf("Employee details:\nID: %d\nName: %s\nSalary: %.2f\n", e.id, e.name, e.salary);
    else
        printf("Employee with ID %d not found.\n", id);
}

void display(FILE *f) {
    struct Employee e;
    rewind(f);
    printf("All Employees:\n");
    while (fread(&e, sizeof(e), 1, f) == 1)
        if (e.id != 0)
            printf("ID: %d, Name: %s, Salary: %.2f\n", e.id, e.name, e.salary);
}

int main() {
    FILE *f = fopen("employees.dat", "rb+");
    if (!f) {
        printf("File doesn't exist. Creating a new file...\n");
        f = fopen("employees.dat", "wb+");
        if (!f) {
            printf("Error creating file. Exiting...\n");
            return 1;
        }
    }

    int choice;
    do {
        printf("Employee Database\n");
        printf("1.\tAdd Employee\n2.\tSearch Employee\n3.\tDisplay All Employees\n4.\tExit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1: add(f); break;
            case 2: search(f); break;
            case 3: display(f); break;
            case 4: printf("Exiting...\n"); break;
            default: printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 4);

    fclose(f);
    return 0;
}
