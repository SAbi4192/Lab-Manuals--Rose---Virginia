#include <stdio.h>
#include <stdlib.h>

int max[100][100], alloc[100][100], need[100][100], avail[100], n, r;

void input() {
    printf("Enter number of processes and resources: ");
    scanf("%d%d", &n, &r);

    printf("Enter Max Resource Matrix:\n");
    for (int i = 0; i < n; i++) {
        printf("P%d: ", i);
        for (int j = 0; j < r; j++)
            scanf("%d", &max[i][j]);
    }

    printf("Enter Allocation Matrix:\n");
    for (int i = 0; i < n; i++) {
        printf("P%d: ", i);
        for (int j = 0; j < r; j++) {
            scanf("%d", &alloc[i][j]);
            need[i][j] = max[i][j] - alloc[i][j];
        }
    }

    printf("Enter Available Resources: ");
    for (int j = 0; j < r; j++)
        scanf("%d", &avail[j]);
}

void checkDeadlock() {
    int f[100] = {0}, s[100], w[100], c = 0;
    for (int i = 0; i < r; i++) w[i] = avail[i];

    while (c < n) {
        int found = 0;
        for (int i = 0; i < n; i++) {
            if (!f[i]) {
                int canExecute = 1;
                for (int j = 0; j < r; j++) {
                    if (need[i][j] > w[j]) {
                        canExecute = 0;
                        break;
                    }
                }
                if (canExecute) {
                    for (int j = 0; j < r; j++)
                        w[j] += alloc[i][j];
                    s[c++] = i;
                    f[i] = 1;
                    found = 1;
                }
            }
        }
        if (!found) {
            printf("\n System is in Deadlock!\nDeadlocked Processes: ");
            for (int i = 0; i < n; i++)
                if (!f[i])
                    printf("P%d ", i);
            printf("\n");
            return;
        }
    }

    printf("\n System is in Safe State.\nSafe Execution Sequence: ");
    for (int i = 0; i < n; i++)
        printf("P%d ", s[i]);
    printf("\n");
}

int main() {
    printf("🔍 Deadlock Detection Algorithm\n");
    input();
    checkDeadlock();
    return 0;
}
