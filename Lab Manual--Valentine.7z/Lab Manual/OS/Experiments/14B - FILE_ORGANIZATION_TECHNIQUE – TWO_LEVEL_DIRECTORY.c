#include <stdio.h>
#include <string.h>

struct {
    char dname[10], fname[10][10];
    int fcnt;
} dir[10];
int dcnt = 0;

void createDir() {
    if (dcnt == 10) return;
    printf("Directory name: ");
    scanf("%s", dir[dcnt].dname);
    dir[dcnt++].fcnt = 0;
}

void createFile() {
    char d[10]; printf("Dir name: "); scanf("%s", d);
    for (int i = 0; i < dcnt; i++) {
        if (!strcmp(d, dir[i].dname)) {
            if (dir[i].fcnt == 10) return;
            printf("File name: ");
            scanf("%s", dir[i].fname[dir[i].fcnt]);
            printf("File '%s' created in '%s'\n", dir[i].fname[dir[i].fcnt], d);
            dir[i].fcnt++;
            return;
        }
    }
    printf("Directory not found\n");
}

void deleteFile() {
    char d[10], f[10]; printf("Dir: "); scanf("%s", d);
    for (int i = 0; i < dcnt; i++) {
        if (!strcmp(d, dir[i].dname)) {
            printf("File: "); scanf("%s", f);
            for (int j = 0; j < dir[i].fcnt; j++) {
                if (!strcmp(f, dir[i].fname[j])) {
                    strcpy(dir[i].fname[j], dir[i].fname[--dir[i].fcnt]);
                    printf("Deleted '%s' from '%s'\n", f, d);
                    return;
                }
            }
            printf("File not found\n");
            return;
        }
    }
    printf("Directory not found\n");
}

void searchFile() {
    char d[10], f[10]; printf("Dir: "); scanf("%s", d);
    for (int i = 0; i < dcnt; i++) {
        if (!strcmp(d, dir[i].dname)) {
            printf("File: "); scanf("%s", f);
            for (int j = 0; j < dir[i].fcnt; j++) {
                if (!strcmp(f, dir[i].fname[j])) {
                    printf("File '%s' found in '%s'\n", f, d);
                    return;
                }
            }
            printf("File not found\n");
            return;
        }
    }
    printf("Directory not found\n");
}

void display() {
    if (dcnt == 0) { printf("No directories\n"); return; }
    for (int i = 0; i < dcnt; i++) {
        printf("%s:", dir[i].dname);
        for (int j = 0; j < dir[i].fcnt; j++)
            printf(" %s", dir[i].fname[j]);
        printf("\n");
    }
}

int main() {
    int ch;
    while (1) {
        printf("\n1.Create Dir 2.Create File 3.Delete File 4.Search File 5.Display 6.Exit\nChoice: ");
        scanf("%d", &ch);
        switch (ch) {
            case 1: createDir(); break;
            case 2: createFile(); break;
            case 3: deleteFile(); break;
            case 4: searchFile(); break;
            case 5: display(); break;
            case 6: return 0;
            default: printf("Invalid\n");
        }
    }
}
