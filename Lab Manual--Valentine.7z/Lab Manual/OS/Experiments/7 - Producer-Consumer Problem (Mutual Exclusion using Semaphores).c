#include <stdio.h>
#include <stdlib.h>

int mutex = 1, full = 0, empty = 3, x = 0;

int wait(int s) { return --s; }
int signal(int s) { return ++s; }

void producer() {
    mutex = wait(mutex);
    full = signal(full);
    empty = wait(empty);
    printf("\nProducer produces item %d\n", ++x);
    mutex = signal(mutex);
}

void consumer() {
    mutex = wait(mutex);
    full = wait(full);
    empty = signal(empty);
    printf("\nConsumer consumes item %d\n", x--);
    mutex = signal(mutex);
}

int main() {
    while (1) {
        int choice;
        printf("\n1. PRODUCER\n2. CONSUMER\n3. EXIT\nENTER YOUR CHOICE: ");
        scanf("%d", &choice);

        if (choice == 1 && mutex == 1 && empty)
            producer();
        else if (choice == 2 && mutex == 1 && full)
            consumer();
        else if (choice == 3)
            exit(0);
        else
            printf(choice == 1 ? "BUFFER IS FULL\n" : choice == 2 ? "BUFFER IS EMPTY\n" : "Invalid choice! Try again.\n");
    }
}
