#include <stdio.h>

struct process {
    int pid, btime, priority, wtime, ttime;
} p[10];

void sortProcesses(struct process p[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (p[i].priority < p[j].priority) {
                struct process temp = p[i];
                p[i] = p[j];
                p[j] = temp;
            }
        }
    }
}

int main() {
    int n, totwtime = 0, totttime = 0;

    printf("Priority Scheduling...\n\n");
    printf("Enter the number of processes: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("\nEnter Burst Time for Process %d: ", p[i].pid);
        scanf("%d", &p[i].btime);
        printf("Enter Priority for Process %d: ", p[i].pid);
        scanf("%d", &p[i].priority);
    }

    sortProcesses(p, n);

    for (int i = 0; i < n; i++) {
        p[i].wtime = (i == 0) ? 0 : p[i - 1].wtime + p[i - 1].btime;
        p[i].ttime = p[i].wtime + p[i].btime;
        totwtime += p[i].wtime;
        totttime += p[i].ttime;
    }

    printf("\n\n%-10s%-10s%-12s%-15s%-15s\n", "Process", "Priority", "Burst Time", "Waiting Time", "Turnaround Time");
    for (int i = 0; i < n; i++) {
        printf("%-10d%-10d%-12d%-15d%-15d\n", p[i].pid, p[i].priority, p[i].btime, p[i].wtime, p[i].ttime);
    }

    printf("\nTotal Waiting Time: %d", totwtime);
    printf("\nAverage Waiting Time: %.2f", (float)totwtime / n);
    printf("\nTotal Turnaround Time: %d", totttime);
    printf("\nAverage Turnaround Time: %.2f\n", (float)totttime / n);

    return 0;
}
