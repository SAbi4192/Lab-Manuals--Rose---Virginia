#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct emp {
    char name[50];
    float salary;
    int age;
    char id[20]; // EMP-ID as string
} e;

long int size = sizeof(e);
FILE *fp, *ft;

void addrecord() {
    char another = 'y';
    fp = fopen("data.txt", "ab");
    while (another == 'y' || another == 'Y') {
        printf("Enter Name : ");
        scanf("%s", e.name);
        printf("Enter Age : ");
        scanf("%d", &e.age);
        printf("Enter Salary : ");
        scanf("%f", &e.salary);
        printf("Enter EMP-ID : ");
        scanf("%s", e.id);
        fwrite(&e, size, 1, fp);
        printf("Want to add another record (Y/N): ");
        getchar(); // consume newline
        scanf("%c", &another);
    }
    fclose(fp);
}

void deleterecord() {
    char empname[50], another = 'y';
    while (another == 'y' || another == 'Y') {
        printf("Enter employee name to delete: ");
        scanf("%s", empname);
        fp = fopen("data.txt", "rb");
        ft = fopen("temp.txt", "wb");
        while (fread(&e, size, 1, fp))
            if (strcmp(e.name, empname) != 0)
                fwrite(&e, size, 1, ft);
        fclose(fp); fclose(ft);
        remove("data.txt");
        rename("temp.txt", "data.txt");
        printf("Want to delete another record (Y/N): ");
        getchar(); scanf("%c", &another);
    }
}

void displayrecord() {
    fp = fopen("data.txt", "rb");
    if (!fp) return;
    printf("=======================================================\n");
    printf("===NAME\tAGE\tSALARY\t\tID\n");
    printf("=======================================================\n");
    while (fread(&e, size, 1, fp))
        printf("===%s\t%d\t%.2f\t%s\n", e.name, e.age, e.salary, e.id);
    fclose(fp);
}

void modifyrecord() {
    char empname[50], another = 'y';
    while (another == 'y' || another == 'Y') {
        printf("Enter employee name to modify: ");
        scanf("%s", empname);
        fp = fopen("data.txt", "rb+");
        while (fread(&e, size, 1, fp)) {
            if (strcmp(e.name, empname) == 0) {
                printf("Enter new name: ");
                scanf("%s", e.name);
                printf("Enter new age: ");
                scanf("%d", &e.age);
                printf("Enter new salary: ");
                scanf("%f", &e.salary);
                printf("Enter new EMP-ID: ");
                scanf("%s", e.id);
                fseek(fp, -size, SEEK_CUR);
                fwrite(&e, size, 1, fp);
                break;
            }
        }
        fclose(fp);
        printf("Want to modify another record (Y/N): ");
        getchar(); scanf("%c", &another);
    }
}

int main() {
    int choice;
    do {
        printf("\n1.\tADD RECORD\n2.\tDELETE RECORD\n3.\tDISPLAY RECORDS\n4.\tMODIFY RECORD\n5.\tEXIT\n");
        printf("ENTER YOUR CHOICE...");
        scanf("%d", &choice);
        switch (choice) {
            case 1: addrecord(); break;
            case 2: deleterecord(); break;
            case 3: displayrecord(); break;
            case 4: modifyrecord(); break;
            case 5: exit(0);
            default: printf("Invalid choice. Try again.\n");
        }
    } while (1);
}
