#include <stdio.h>

void roundRobinScheduling(int p[], int n, int bt[], int q) {
    int rbt[n], wt[n], tt[n], t = 0, c = 0;

    for (int i = 0; i < n; i++)
        rbt[i] = bt[i];

    while (c < n)
        for (int i = 0; i < n; i++)
            if (rbt[i] > 0) {
                int exec = (rbt[i] > q) ? q : rbt[i];
                t += exec;
                rbt[i] -= exec;
                if (rbt[i] == 0) {
                    wt[i] = t - bt[i];
                    c++;
                }
            }

    for (int i = 0; i < n; i++)
        tt[i] = wt[i] + bt[i];

    printf("\nP\tBT\tWT\tTT\n");
    for (int i = 0; i < n; i++)
        printf("%d\t%d\t%d\t%d\n", p[i], bt[i], wt[i], tt[i]);

    float avgWT = 0, avgTT = 0;
    for (int i = 0; i < n; i++) {
        avgWT += wt[i];
        avgTT += tt[i];
    }

    printf("\nAvg WT: %.2f\nAvg TT: %.2f\n", avgWT / n, avgTT / n);
}

int main() {
    int n, q;
    printf("\nRound Robin Scheduling...\nEnter number of processes: ");
    scanf("%d", &n);

    int p[n], bt[n];
    for (int i = 0; i < n; i++) {
        p[i] = i + 1;
        printf("Enter Burst Time for P%d: ", p[i]);
        scanf("%d", &bt[i]);
    }

    printf("Enter Time Quantum: ");
    scanf("%d", &q);

    roundRobinScheduling(p, n, bt, q);
    return 0;
}
