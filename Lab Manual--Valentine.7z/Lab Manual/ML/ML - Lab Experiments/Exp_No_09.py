import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Load data from renamed CSV
data = pd.read_csv("D:/ML_CSV/Jackie_Merlin-J.csv")
X = data['X'].values
Y = data['Y'].values

# Locally Weighted Regression Function
def kernel(x, x_i, tau):
    return np.exp(-np.square(x - x_i) / (2 * tau * tau))

def locally_weighted_regression(x0, X, Y, tau):
    m = len(X)
    W = np.eye(m)
    for i in range(m):
        W[i][i] = kernel(x0, X[i], tau)
    X_ = np.vstack((np.ones(m), X)).T
    theta = np.linalg.pinv(X_.T @ W @ X_) @ X_.T @ W @ Y
    return np.dot([1, x0], theta)

# Predict and Plot
X_test = np.linspace(min(X), max(X), 100)
Y_pred = [locally_weighted_regression(x, X, Y, tau=0.5) for x in X_test]

plt.scatter(X, Y, color='blue', label='Original Data')
plt.plot(X_test, Y_pred, color='red', label='LWR Prediction')
plt.xlabel("X")
plt.ylabel("Y")
plt.title("Locally Weighted Regression")
plt.legend()
plt.show()
