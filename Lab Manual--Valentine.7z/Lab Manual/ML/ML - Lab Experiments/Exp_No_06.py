from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination

# Define the structure of the Bayesian Network
model = DiscreteBayesianNetwork([
    ('Fever', 'Corona'),
    ('Cough', 'Corona'),
    ('Breathlessness', 'Corona')
])

# Define CPDs
cpd_fever = TabularCPD(variable='Fever', variable_card=2, values=[[0.5], [0.5]])
cpd_cough = TabularCPD(variable='Cough', variable_card=2, values=[[0.5], [0.5]])
cpd_breath = TabularCPD(variable='Breathlessness', variable_card=2, values=[[0.5], [0.5]])

cpd_corona = TabularCPD(
    variable='Corona',
    variable_card=2,
    values=[
        [0.9, 0.7, 0.8, 0.6, 0.5, 0.3, 0.4, 0.2],  # No Corona
        [0.1, 0.3, 0.2, 0.4, 0.5, 0.7, 0.6, 0.8]   # Corona
    ],
    evidence=['Fever', 'Cough', 'Breathlessness'],
    evidence_card=[2, 2, 2]
)

# Add CPDs to the model
model.add_cpds(cpd_fever, cpd_cough, cpd_breath, cpd_corona)

# Validate the model
assert model.check_model(), "Model is invalid"

# Inference
inference = VariableElimination(model)
result = inference.query(
    variables=['Corona'],
    evidence={'Fever': 1, 'Cough': 1, 'Breathlessness': 1}
)

# Output
print(result)
