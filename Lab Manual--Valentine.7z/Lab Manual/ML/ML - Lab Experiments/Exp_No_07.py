import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.mixture import GaussianMixture
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score

# Load dataset
data = pd.read_csv("D:/ML_CSV/Jeni_espresso.csv")

# Normalize the data
scaler = StandardScaler()
X = scaler.fit_transform(data)

# Apply K-Means
kmeans = KMeans(n_clusters=2, random_state=42)
kmeans_labels = kmeans.fit_predict(X)

# Apply EM algorithm using Gaussian Mixture Model
gmm = GaussianMixture(n_components=2, random_state=42)
gmm_labels = gmm.fit_predict(X)

# Compare the clustering results using Adjusted Rand Index
ari_score = adjusted_rand_score(kmeans_labels, gmm_labels)

print("K-Means Labels:", kmeans_labels)
print("GMM (EM) Labels:", gmm_labels)
print(f"\nSimilarity between the two clusterings (ARI Score): {ari_score:.2f}")
