import csv
# Function to perform the Candidate-Elimination algorithm
def candidate_elimination(data):
    # Initialize Specific Hypothesis (S) with the first positive example
    S = data[0][:-1]
    # Initialize General Hypothesis (G) with the most general hypothesis
    G = [['?' for _ in S]]
    # Process each training example
    for row in data:
        x, y = row[:-1], row[-1].lower()  # Split attributes and label
        if y == 'yes':
            # Update specific hypothesis S
            for i in range(len(S)):
                if S[i] != x[i]:
                    S[i] = '?'  # Generalize S where it differs
        else:
            # Update general hypotheses G
            G = [g[:i] + [S[i]] + g[i+1:]
                 for g in G for i in range(len(S))
                 if S[i] != '?' and x[i] != S[i]]
 # Remove duplicates in G
    G = [list(t) for t in {tuple(g) for g in G}]
    return S, G
# Load CSV data (skipping the header row)
with open('D:/ML_CSV/PoPCorn_Musk.csv', 'r') as f:
    data = list(csv.reader(f))[1:]
# Run the algorithm
S, G = candidate_elimination(data)
# Display results
print("Final Specific Hypothesis:", S)
print("Final General Hypotheses:", G)
