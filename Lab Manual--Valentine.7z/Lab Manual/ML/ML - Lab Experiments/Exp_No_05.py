from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score

# Mini document dataset
documents = [
    "Football is fun",        # sports
    "He scored a goal",       # sports
    "Python is amazing",      # tech
    "I enjoy coding",         # tech
    "Great football match",   # sports
    "Programming is fun",     # tech
]

labels = ['sports', 'sports', 'tech', 'tech', 'sports', 'tech']

# Convert text to TF-IDF features
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(documents)
y = labels

# Split data with stratify to keep class balance
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.33, random_state=42, stratify=y)

# Train Naive Bayes model
model = MultinomialNB()
model.fit(X_train, y_train)

# Predict and evaluate
y_pred = model.predict(X_test)

print("Predicted:", y_pred)
print("Actual   :", y_test)
print("Accuracy :", accuracy_score(y_test, y_pred) * 100)
print("Precision:", precision_score(y_test, y_pred, average='macro', zero_division=0) * 100)
print("Recall   :", recall_score(y_test, y_pred, average='macro', zero_division=0) * 100)
