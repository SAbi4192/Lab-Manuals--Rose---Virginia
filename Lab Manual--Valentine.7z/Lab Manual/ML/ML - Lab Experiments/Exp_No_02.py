import csv, math
from collections import Counter

# Function to calculate entropy of a dataset
def entropy(data):
    total = len(data)
    label_counts = Counter(row[-1] for row in data)  # Count class labels
    return -sum((count/total) * math.log2(count/total) for count in label_counts.values())

# Function to compute information gain for an attribute
def info_gain(data, attr_index):
    total_entropy = entropy(data)
    subsets = {}
    for row in data:
        key = row[attr_index]
        subsets.setdefault(key, []).append(row)
    subset_entropy = sum((len(subset)/len(data)) * entropy(subset) for subset in subsets.values())
    return total_entropy - subset_entropy

# Recursive ID3 function to build the decision tree
def id3(data, attributes):
    labels = [row[-1] for row in data]
    
    # If all instances have the same label, return that label
    if labels.count(labels[0]) == len(labels):
        return labels[0]

    # If no more attributes, return the majority label
    if not attributes:
        return Counter(labels).most_common(1)[0][0]

    # Select the attribute with the highest information gain
    best_attr = max(attributes, key=lambda i: info_gain(data, i))
    tree = {best_attr: {}}

    # Split the dataset on the best attribute and recurse
    for val in set(row[best_attr] for row in data):
        subset = [row for row in data if row[best_attr] == val]
        remaining_attrs = [i for i in attributes if i != best_attr]
        tree[best_attr][val] = id3(subset, remaining_attrs)

    return tree

# Function to classify a sample using the built decision tree
def classify(tree, sample):
    while isinstance(tree, dict):
        attr = next(iter(tree))          # Get the attribute index
        value = sample[attr]             # Access sample using index
        tree = tree[attr].get(value, "Unknown")  # Handle unseen values
    return tree

# Load training data from the CSV file
with open('D:/ML_CSV/Terror_02.csv') as f:
    reader = csv.reader(f)
    header = next(reader)     # Read the header (attribute names)
    data = list(reader)       # Load the remaining data

# Build the decision tree from training data
attributes = list(range(len(header) - 1))  # Attribute indices
tree = id3(data, attributes)

# Define a new sample to classify (order must match the CSV)
sample = ['Sunny', 'Cool', 'High', 'Strong']  # Example sample as list

# Output the decision tree and classification result
print("Final Decision Tree:", tree)
print("New Sample:", sample)
print("Classified as:", classify(tree, sample))
