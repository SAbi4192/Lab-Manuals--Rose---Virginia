import java.net.*;
import java.io.*;

public class TCPserver1 {
    public static void main(String arg[]) {
        ServerSocket s = null;
        String line;
        DataInputStream is = null, is1 = null;
        PrintStream os = null;
        Socket c = null;

        try {
            s = new ServerSocket(9999);
            System.out.println("Server started. Waiting for client...");
        } catch (IOException e) {
            System.out.println("Server socket error: " + e);
        }

        try {
            c = s.accept();
            System.out.println("Client connected.");
            is = new DataInputStream(c.getInputStream());
            is1 = new DataInputStream(System.in);
            os = new PrintStream(c.getOutputStream());

            do {
                line = is.readLine();  // read from client
                System.out.println("Client: " + line);

                System.out.print("Server: ");
                line = is1.readLine();  // read from server user input
                os.println(line);       // send to client
            } while (!line.equalsIgnoreCase("quit"));

            is.close();
            os.close();
            c.close();
            s.close();
        } catch (IOException e) {
            System.out.println("I/O error: " + e);
        }
    }
}
