import java.net.*;
import java.io.*;

public class TCPclient1 {
    public static void main(String arg[]) {
        Socket c = null;
        String line;
        DataInputStream is, is1;
        PrintStream os;

        try {
            c = new Socket("localhost", 9999);  // change IP if needed
            System.out.println("Connected to server.");
        } catch (IOException e) {
            System.out.println("Connection error: " + e);
            return;
        }

        try {
            os = new PrintStream(c.getOutputStream());
            is = new DataInputStream(System.in);         // read user input
            is1 = new DataInputStream(c.getInputStream()); // read from server

            do {
                System.out.print("Client: ");
                line = is.readLine();
                os.println(line);
                if (!line.equalsIgnoreCase("quit"))
                    System.out.println("Server: " + is1.readLine());
            } while (!line.equalsIgnoreCase("quit"));

            is.close();
            is1.close();
            os.close();
            c.close();
        } catch (IOException e) {
            System.out.println("Socket closed! Message passing is over.");
        }
    }
}
