import java.io.*;
import java.net.*;

public class eclient {
    public static void main(String args[]) {
        Socket c = null;
        String line;
        DataInputStream is, is1;
        PrintStream os;

        try {
            c = new Socket("localhost", 8080);
            System.out.println("Connected to server at localhost:8080");
        } catch(IOException e) {
            System.out.println("Connection failed: " + e);
            return;
        }

        try {
            os = new PrintStream(c.getOutputStream());
            is = new DataInputStream(System.in);
            is1 = new DataInputStream(c.getInputStream());

            while (true) {
                System.out.print("Client: ");
                line = is.readLine();
                os.println(line);  // Send to server
                if (line.equalsIgnoreCase("exit")) break;

                String reply = is1.readLine();  // Receive from server
                System.out.println("Server: " + reply);
            }

            is.close();
            is1.close();
            os.close();
            c.close();

        } catch(IOException e) {
            System.out.println("Socket closed or error: " + e);
        }
    }
}
