import java.io.*;
import java.net.*;

public class eserver {
    public static void main(String args[]) throws IOException {
        ServerSocket s = null;
        String line;
        DataInputStream is;
        PrintStream ps;
        Socket c = null;

        try {
            s = new ServerSocket(8080);
            System.out.println("Server started. Waiting for client...");
        } catch(IOException e) {
            System.out.println("Server socket error: " + e);
        }

        try {
            c = s.accept();
            System.out.println("Client connected.");
            is = new DataInputStream(c.getInputStream());
            ps = new PrintStream(c.getOutputStream());

            while (true) {
                line = is.readLine();
                if (line.equalsIgnoreCase("exit")) break;
                System.out.println("Received: " + line);
                ps.println(line);  // Send back to client
            }

            is.close();
            ps.close();
            c.close();
            s.close();
        } catch(IOException e) {
            System.out.println("Connection error: " + e);
        }
    }
}
