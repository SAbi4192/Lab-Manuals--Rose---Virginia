import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.tsa.arima.model import ARIMA

# Load dataset
url = 'https://raw.githubusercontent.com/jbrownlee/Datasets/master/airline-passengers.csv'
df = pd.read_csv(url, header=0, parse_dates=[0], index_col=0)

# Plot Time Series Data
plt.plot(df, label='Airline Passengers')
plt.title('Monthly Airline Passengers (1949 - 1960)')
plt.xlabel('Year'), plt.ylabel('Number of Passengers')
plt.legend(), plt.show()

# Decomposing Time Series
decomposition = seasonal_decompose(df, model='multiplicative', period=12)
decomposition.plot()
plt.show()

# Stationarity Check using ADF Test
adf_test = adfuller(df)
print("ADF Test Statistic:", adf_test[0])
print("p-value:", adf_test[1])

# ACF and PACF Plots
plot_acf(df, lags=50)
plt.title('Autocorrelation Function (ACF)')
plt.show()

plot_pacf(df, lags=50)
plt.title('Partial Autocorrelation Function (PACF)')
plt.show()

# Build ARIMA Model
model = ARIMA(df, order=(1, 1, 1))
model_fit = model.fit()
print(model_fit.summary())

# Forecast Next 12 Months
forecast = model_fit.forecast(steps=12)
plt.plot(df, label='Original Series')
plt.plot(pd.date_range(df.index[-1], periods=12, freq='M'), forecast, label='Forecast', color='red')
plt.title('Time Series Forecasting (Next 12 Months)')
plt.xlabel('Year'), plt.ylabel('Number of Passengers')
plt.legend(), plt.show()
