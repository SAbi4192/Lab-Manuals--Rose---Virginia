import numpy as np

# Average Calculation
data_avg = [2, 40, 2, 502, 177, 7, 9]
print("Average:", np.average(data_avg))

# Variance Calculation
data_var = [2, 4, 4, 4, 5, 5, 7, 9]
print("Variance:", np.var(data_var))

# Standard Deviation Calculation
data_std = [290, 124, 127, 899]
print("Standard Deviation:", np.std(data_std))
