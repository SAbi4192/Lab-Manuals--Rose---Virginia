import numpy as np
import scipy.stats as stats

# Sample data for three independent groups
group1 = [23, 20, 22, 21, 24]
group2 = [30, 31, 29, 32, 28]
group3 = [27, 25, 26, 24, 28]

# Perform one-way ANOVA
f_stat, p_value = stats.f_oneway(group1, group2, group3)

# Display results
print(f"F-statistic: {f_stat:.4f}")
print(f"P-value: {p_value:.4f}")

# Interpretation
alpha = 0.05
result = "Reject the null hypothesis (At least one group mean is significantly different)" if p_value < alpha else "Fail to reject the null hypothesis (No significant difference among group means)"
print(result)
