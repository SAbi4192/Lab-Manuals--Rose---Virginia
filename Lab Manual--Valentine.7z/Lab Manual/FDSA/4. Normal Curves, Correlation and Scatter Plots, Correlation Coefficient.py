import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from scipy.stats import norm

# Normal Curve
x = np.linspace(-4, 4, 1000)
y = norm.pdf(x, 0, 1)
plt.plot(x, y, label='Normal Distribution (mu=0, sigma=1)')
plt.title('Normal Distribution Curve')
plt.xlabel('X'), plt.ylabel('Probability Density')
plt.legend(), plt.grid(True)
plt.show()

# Correlation and Scatter Plot
np.random.seed(0)
x = np.random.rand(100)
y = 2 * x + np.random.normal(0, 0.1, 100)
data = pd.DataFrame({'X': x, 'Y': y})
correlation = data.corr()
print("Correlation Matrix:\n", correlation)

plt.scatter(data['X'], data['Y'], color='blue', alpha=0.7)
plt.title('Scatter Plot of X vs Y')
plt.xlabel('X'), plt.ylabel('Y')
plt.grid(True)
plt.show()

# Correlation Matrix Heatmap
sns.heatmap(correlation, annot=True, cmap='coolwarm', fmt=".2f", linewidths=0.5)
plt.title('Correlation Matrix Heatmap')
plt.show()

# Pearson Correlation Coefficient
x_vals, y_vals = [1, 2, 3, 4, 5], [5, 4, 3, 2, 1]
correlation_matrix = np.corrcoef(x_vals, y_vals)
print(f"Pearson Correlation Coefficient: {correlation_matrix[0, 1]:.5f}")
