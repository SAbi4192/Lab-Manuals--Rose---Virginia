import pandas as pd

df = pd.DataFrame({'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva'], 'Age': [24, 27, 22, 32, 29],
                   'City': ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix'],
                   'Salary': [70000, 80000, 120000, 90000, 85000]})

print("Original DataFrame:\n", df, "\nSelect 'Name' column:\n", df['Name'])
print("\nEmployees with salary greater than 80k:\n", df[df['Salary'] > 80000])

df['Experience'] = [2, 5, 1, 8, 6]
print("\nDataFrame with Experience column:\n", df)

df.loc[1, 'Salary'] = None  # Introduce NaN
print("\nDataFrame with missing salary data:\n", df)

df['Salary'] = df['Salary'].fillna(df['Salary'].mean())  # Fix warning
print("\nDataFrame after filling missing values:\n", df)

print("\nAverage salary by city:\n", df.groupby('City')['Salary'].mean())
print("\nDataFrame sorted by salary (descending):\n", df.sort_values(by='Salary', ascending=False))
print("\nDataFrame sorted and index reset:\n", df.sort_values(by='Salary', ascending=False).reset_index(drop=True))
