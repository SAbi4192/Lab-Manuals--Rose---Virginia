import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 10, 100)
y1, y2 = np.sin(x), np.cos(x)

# Line Plot
plt.plot(x, y1, label='sin(x)', color='blue')
plt.plot(x, y2, label='cos(x)', color='red')
plt.title("Basic Line Plot")
plt.xlabel("X-axis"), plt.ylabel("Y-axis")
plt.legend(), plt.grid(True)
plt.show()

# Scatter Plot
plt.scatter(x, y1, color='green', label='sin(x)')
plt.title("Basic Scatter Plot")
plt.xlabel("X-axis"), plt.ylabel("Y-axis")
plt.legend(), plt.grid(True)
plt.show()

# Bar Plot
categories, values = ['A', 'B', 'C', 'D', 'E'], [10, 15, 7, 10, 5]
plt.bar(categories, values, color='purple')
plt.title("Basic Bar Plot")
plt.xlabel("Categories"), plt.ylabel("Values")
plt.grid(True)
plt.show()

# Histogram
plt.hist(np.random.randn(1000), bins=30, color='orange', edgecolor='black')
plt.title("Basic Histogram")
plt.xlabel("Value"), plt.ylabel("Frequency")
plt.grid(True)
plt.show()

# Pie Chart
sizes, labels = [30, 20, 25, 25], ['A', 'B', 'C', 'D']
plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
plt.title("Basic Pie Chart")
plt.show()
