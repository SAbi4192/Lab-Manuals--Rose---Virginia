import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

# Sample Data (X: Independent variable, y: Dependent variable)
X = np.array([[1], [2], [3], [4], [5], [6], [7], [8], [9], [10]])
y = np.array([1, 2, 1.3, 3.75, 3.2, 4.4, 4.7, 5.8, 6.1, 7.3])

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model Creation & Prediction
model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Print coefficients
print("Intercept:", model.intercept_)
print("Coefficient:", model.coef_[0])

# Model Evaluation
print("Mean Squared Error:", mean_squared_error(y_test, y_pred))
print("R^2 Score:", r2_score(y_test, y_pred))

# Plot results
plt.scatter(X_test, y_test, color='blue', label='Actual data')
plt.plot(X_test, y_pred, color='red', linewidth=2, label='Regression line')
plt.title('Simple Linear Regression')
plt.xlabel('X'), plt.ylabel('y')
plt.legend()
plt.show()
