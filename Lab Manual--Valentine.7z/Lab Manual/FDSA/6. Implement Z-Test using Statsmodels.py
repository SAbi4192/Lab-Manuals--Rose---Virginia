from statsmodels.stats.weightstats import ztest

# One-Sample Z-Test
data = [88, 92, 94, 94, 96, 97, 97, 97, 90, 99, 105, 109, 109, 100, 110, 112, 112, 113, 114, 115]
print("One-Sample Z-Test:", ztest(data, value=100))

# Two-Sample Z-Test
cityA = [82, 84, 85, 89, 91, 91, 92, 94, 99, 99, 105, 109, 109, 109, 110, 112, 112, 113, 114, 114]
cityB = [90, 91, 91, 95, 95, 99, 99, 108, 109, 109, 114, 115, 116, 117, 117, 128, 129, 130, 133]
print("Two-Sample Z-Test:", ztest(cityA, cityB))
