import numpy as np
import scipy.stats as stats

# One-Sample T-Test
data = [14, 14, 16, 13, 12, 17, 15, 14, 15, 13, 15, 14]
print("One-Sample T-Test:", stats.ttest_1samp(data, popmean=15))

# Two-Sample T-Test
group1 = np.array([14, 15, 15, 16, 13, 8, 14, 17, 16, 14, 19, 20, 21, 15, 15, 16, 16, 13, 14, 12])
group2 = np.array([15, 17, 14, 17, 14, 8, 12, 19, 19, 14, 17, 22, 24, 16, 13, 16, 13, 18, 15, 13])

print("Group Variances:", np.var(group1), np.var(group2))
print("Two-Sample T-Test:", stats.ttest_ind(group1, group2, equal_var=True))
