void setup() {
  pinMode(4, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  char InChar = Serial.read();

  if(InChar == 'A') {
    digitalWrite(4, HIGH);
  }
  else if(InChar == 'B') {
    digitalWrite(4, LOW);
  }
}